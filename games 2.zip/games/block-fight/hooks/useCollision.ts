import { intersects } from '../engine/collisions';
import { type GameState, type GameUi } from '../engine/types';

type UiSetter = React.Dispatch<React.SetStateAction<GameUi>>;

export function updateCollectibles(state: GameState, setUi: UiSetter) {
  const player = state.player;

  state.coins.forEach(coin => {
    if (!coin.collected && intersects(player, { x: coin.x, y: coin.y, w: 16, h: 16 })) {
      coin.collected = true;
      state.score += 10;
      setUi(ui => ({ ...ui, score: state.score }));
    }
  });
}

export function updateWinCondition(state: GameState, setUi: UiSetter) {
  if (state.enemies.every(enemy => !enemy.alive) && state.coins.every(coin => coin.collected)) {
    state.gameState = 'win';
    setUi(ui => ({ ...ui, state: 'win' }));
  }
}
